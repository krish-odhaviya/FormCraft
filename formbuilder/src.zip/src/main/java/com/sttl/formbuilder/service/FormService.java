package com.sttl.formbuilder.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import com.sttl.formbuilder.Enums.FormStatusEnum;
import com.sttl.formbuilder.dto.FieldDto;
import com.sttl.formbuilder.dto.VersionDto;
import com.sttl.formbuilder.entity.User;
import com.sttl.formbuilder.exception.BusinessException;
import com.sttl.formbuilder.repository.UserRepository;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.sttl.formbuilder.dto.FormDetailsResponse;
import com.sttl.formbuilder.entity.Form;
import com.sttl.formbuilder.entity.FormField;
import com.sttl.formbuilder.repository.FormFieldRepository;
import com.sttl.formbuilder.repository.FormRepository;

@Service
public class FormService {

    private final FormRepository formRepository;
    private final FormFieldRepository formFieldRepository;
    private final UserRepository userRepository;
    private final PermissionService permissionService;

    public FormService(FormRepository formRepository,
                       FormFieldRepository formFieldRepository,
                       UserRepository userRepository,
                       PermissionService permissionService) {
        this.formRepository = formRepository;
        this.formFieldRepository = formFieldRepository;
        this.userRepository = userRepository;
        this.permissionService = permissionService;
    }

    /** Returns forms the user has access to manage (Owner or Admin or Builder). */
    public List<Form> getAllForms(String currentUsername) {
        User user = userRepository.findByUsername(currentUsername)
                .orElseThrow(() -> new RuntimeException("User not found"));
        
        if (permissionService.canManageSystem(user)) {
            return formRepository.findAll();
        }
        
        return formRepository.findFormsAccessibleToUser(user);
    }

    /** Creates a form tagged with the current user as owner. */
    public Form createForm(String name, String description, String currentUsername) {
        User user = userRepository.findByUsername(currentUsername)
                .orElseThrow(() -> new RuntimeException("User not found"));

        if (formRepository.existsByNameAndOwner(name, user)) {
            throw new RuntimeException("You already have a form with that name");
        }

        Form form = new Form();
        form.setName(name);
        form.setDescription(description);
        form.setCreatedByUsername(currentUsername);
        form.setOwner(user);

        return formRepository.save(form);
    }

    /**
     * Fetches a form's full structure.
     * Pass currentUsername=null for public access (form fill),
     * or a real username to enforce ownership.
     */
    public FormDetailsResponse getFormWithStructure(Long formId, String currentUsername) {
        Form form = formRepository.findById(formId)
                .orElseThrow(() -> new RuntimeException("Form not found"));

        User user = currentUsername != null ? userRepository.findByUsername(currentUsername).orElse(null) : null;
        
        System.out.println("FormService.getFormWithStructure: formId=" + formId + 
                           " visibility=" + form.getVisibility() + 
                           " user=" + (user != null ? user.getUsername() : "ANONYMOUS"));

        if (!permissionService.canViewForm(user, form)) {
            System.out.println("  Access Denied by permissionService");
            if (user == null) {
                throw new BusinessException("Authentication required to view this form", HttpStatus.UNAUTHORIZED);
            } else {
                throw new BusinessException("You do not have permission to view this form", HttpStatus.FORBIDDEN);
            }
        }

        FormDetailsResponse response = new FormDetailsResponse();
        response.setId(form.getId());
        response.setName(form.getName());
        response.setDescription(form.getDescription());
        response.setCreatedAt(form.getCreatedAt());
        response.setUpdatedAt(form.getUpdatedAt());
        response.setStatus(String.valueOf(form.getStatus()));
        response.setVisibility(form.getVisibility() != null ? form.getVisibility().name() : "PUBLIC");
        response.setTableName(form.getTableName());
        response.setPublishedAt(form.getPublishedAt());
        response.setCanEdit(permissionService.canConfigureForm(user, form));
        response.setCanViewSubmissions(permissionService.canViewSubmissions(user, form));
        response.setCanDeleteSubmissions(user != null && (permissionService.canManageSystem(user) || permissionService.canDeleteSubmissions(user, form)));
        response.setOwnerName(form.getOwner() != null ? form.getOwner().getUsername() : "Unknown");
        response.setOwnerId(form.getOwner() != null ? form.getOwner().getId() : null);

        // 2. Fetch Fields for this form
        List<FormField> fields = formFieldRepository
                .findByFormIdAndIsDeletedFalseOrderByFieldOrder(form.getId());

        // 3. Map Entities to FieldDto with Nested Maps
        List<FieldDto> fieldDtos = fields.stream()
                .map(f -> {
                    FieldDto fd = new FieldDto();
                    fd.setId(f.getId());
                    fd.setFieldKey(f.getFieldKey());
                    fd.setParentId(f.getParentId());
                    fd.setFieldLabel(f.getFieldLabel());
                    fd.setFieldType(f.getFieldType());
                    fd.setRequired(f.getRequired());
                    fd.setConditions(f.getConditions());
                    fd.setFieldOrder(f.getFieldOrder());

                    // --- Map Options (from separate table) ---
                    if (f.getOptions() != null) {
                        fd.setOptions(new ArrayList<>(f.getOptions()));
                    }

                    // --- Map Validation (Entity Columns -> Map) ---
                    Map<String, Object> validationMap = new HashMap<>();
                    if (f.getMinLength()         != null) validationMap.put("minLength",         f.getMinLength());
                    if (f.getMaxLength()         != null) validationMap.put("maxLength",         f.getMaxLength());
                    if (f.getMinValue()          != null) validationMap.put("min",               f.getMinValue());
                    if (f.getMaxValue()          != null) validationMap.put("max",               f.getMaxValue());
                    if (f.getPattern()           != null) validationMap.put("pattern",           f.getPattern());
                    if (f.getValidationMessage() != null) validationMap.put("validationMessage", f.getValidationMessage());
                    if (f.getIsUnique()          != null) validationMap.put("unique",            f.getIsUnique());
                    // ✅ Grid rows and columns
                    if (f.getGridRows() != null && !f.getGridRows().isEmpty())
                        validationMap.put("rows", f.getGridRows());
                    if (f.getGridColumns() != null && !f.getGridColumns().isEmpty())
                        validationMap.put("columns", f.getGridColumns());
                    fd.setValidation(validationMap);

                    // --- Map UI Config (Entity Columns -> Map) ---
                    Map<String, Object> uiMap = new HashMap<>();
                    if (f.getPlaceholder()  != null) uiMap.put("placeholder",  f.getPlaceholder());
                    if (f.getHelpText()     != null) uiMap.put("helpText",      f.getHelpText());
                    if (f.getDefaultValue() != null) uiMap.put("defaultValue",  f.getDefaultValue());
                    if (f.getReadOnly()     != null) uiMap.put("readOnly",      f.getReadOnly());
                    if (f.getIsHidden()     != null) uiMap.put("hidden",        f.getIsHidden());
                    // ✅ Star rating
                    if (f.getMaxStars()     != null) uiMap.put("maxStars",      f.getMaxStars());
                    // ✅ Linear scale
                    if (f.getScaleMin()     != null) uiMap.put("scaleMin",      f.getScaleMin());
                    if (f.getScaleMax()     != null) uiMap.put("scaleMax",      f.getScaleMax());
                    if (f.getLowLabel()     != null) uiMap.put("lowLabel",      f.getLowLabel());
                    if (f.getHighLabel()    != null) uiMap.put("highLabel",     f.getHighLabel());
                    // ✅ File upload
                    if (f.getMaxFileSizeMb() != null) uiMap.put("maxFileSizeMb", f.getMaxFileSizeMb());
                    if (f.getAcceptedFileTypes() != null && !f.getAcceptedFileTypes().isEmpty())
                        uiMap.put("acceptedFileTypes", f.getAcceptedFileTypes());

                    //foreign key
                    if (f.getSourceTable()         != null) uiMap.put("sourceTable",         f.getSourceTable());
                    if (f.getSourceColumn()        != null) uiMap.put("sourceColumn",        f.getSourceColumn());
                    if (f.getSourceDisplayColumn() != null) uiMap.put("sourceDisplayColumn", f.getSourceDisplayColumn());
                    fd.setUiConfig(uiMap);

                    return fd;
                })
                .collect(Collectors.toList());

        response.setFields(fieldDtos);
        return response;
    }
    public Form archiveForm(Long formId, String currentUsername) {
        Form form = formRepository.findById(formId)
                .orElseThrow(() -> new RuntimeException("Form not found"));
        
        User user = userRepository.findByUsername(currentUsername)
                .orElseThrow(() -> new RuntimeException("User not found"));

        if (!permissionService.canConfigureForm(user, form)) {
            throw new RuntimeException("Access denied: only owners or builders can archive");
        }
        
        form.setStatus(com.sttl.formbuilder.Enums.FormStatusEnum.ARCHIVED);
        return formRepository.save(form);
    }
}
